package com.example.armorest.model;

/** Vanilla (Java Edition) armor material constants. UNKNOWN means "could not be identified". */
public enum ArmorMaterialType {
    LEATHER(5, new int[]{1, 3, 2, 1}, 0),
    GOLD(7, new int[]{2, 5, 3, 1}, 0),
    CHAINMAIL(15, new int[]{2, 5, 4, 1}, 0),
    IRON(15, new int[]{2, 6, 5, 2}, 0),
    DIAMOND(33, new int[]{3, 8, 6, 3}, 2),
    NETHERITE(37, new int[]{3, 8, 6, 3}, 3),
    TURTLE(25, new int[]{2, 0, 0, 0}, 0),
    UNKNOWN(0, new int[]{0, 0, 0, 0}, 0);

    private final int durabilityMultiplier;
    private final int[] defense;
    private final int toughness;

    ArmorMaterialType(int durabilityMultiplier, int[] defense, int toughness) {
        this.durabilityMultiplier = durabilityMultiplier;
        this.defense = defense;
        this.toughness = toughness;
    }

    public boolean isKnown() { return this != UNKNOWN; }
    /** Max durability of this piece, or 0 if unknown. */
    public int maxDurability(ArmorSlot slot) { return durabilityMultiplier * slot.baseDurability(); }
    public int defense(ArmorSlot slot) { return defense[slot.ordinal()]; }
    public int toughness() { return toughness; }
}
