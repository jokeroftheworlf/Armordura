package com.example.armorest.config;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;
import java.util.function.*;

/** Dependency-free settings menu (cycle buttons, 3 pages). Click a button to cycle its value. */
public final class ConfigScreen extends Screen {
    private record Opt(String label, Supplier<String> value, Runnable next) {}

    private static final int PER_PAGE = 12;
    private final Screen parent;
    private final ModConfig c;
    private final List<Opt> opts = new ArrayList<>();
    private int page = 0;

    public ConfigScreen(Screen parent, ModConfig config) {
        super(Text.literal("Armor Estimator Settings"));
        this.parent = parent;
        this.c = config;
        build();
    }

    private void build() {
        opts.add(bool("Mod enabled", () -> c.enabled, v -> c.enabled = v));
        opts.add(bool("HUD enabled", () -> c.hudEnabled, v -> c.hudEnabled = v));
        opts.add(bool("Tracking enabled", () -> c.trackingEnabled, v -> c.trackingEnabled = v));
        opts.add(en("Target mode", () -> c.targetMode, v -> c.targetMode = v, ModConfig.TargetMode.values()));
        opts.add(en("HUD anchor", () -> c.anchor, v -> c.anchor = v, ModConfig.Anchor.values()));
        opts.add(num("HUD offset X", () -> c.offsetX, v -> c.offsetX = v, new int[]{-100, -50, -20, 0, 6, 20, 50, 100}));
        opts.add(num("HUD offset Y", () -> c.offsetY, v -> c.offsetY = v, new int[]{-100, -60, -40, -20, 0, 20, 40, 60, 100}));
        opts.add(dbl("HUD scale", () -> c.hudScale, v -> c.hudScale = v, new double[]{0.6, 0.8, 1.0, 1.25, 1.5, 2.0}));
        opts.add(dbl("HUD opacity", () -> c.hudOpacity, v -> c.hudOpacity = v, new double[]{0.25, 0.5, 0.75, 0.9, 1.0}));
        opts.add(en("Layout", () -> c.layout, v -> c.layout = v, ModConfig.Layout.values()));
        opts.add(en("Bar style", () -> c.barStyle, v -> c.barStyle = v, ModConfig.BarStyle.values()));
        opts.add(en("Color scheme", () -> c.colorScheme, v -> c.colorScheme = v, ModConfig.Scheme.values()));

        opts.add(bool("Show wear", () -> c.showWear, v -> c.showWear = v));
        opts.add(bool("Show confidence", () -> c.showConfidence, v -> c.showConfidence = v));
        opts.add(bool("Show range", () -> c.showRange, v -> c.showRange = v));
        opts.add(bool("Show hits", () -> c.showHits, v -> c.showHits = v));
        opts.add(bool("Show crits", () -> c.showCrits, v -> c.showCrits = v));
        opts.add(bool("Show damage", () -> c.showDamage, v -> c.showDamage = v));
        opts.add(bool("Show combo", () -> c.showCombo, v -> c.showCombo = v));
        opts.add(bool("Show per-piece", () -> c.showPieces, v -> c.showPieces = v));
        opts.add(bool("Only in combat", () -> c.onlyInCombat, v -> c.onlyInCombat = v));
        opts.add(bool("Fade after combat", () -> c.fadeAfterCombat, v -> c.fadeAfterCombat = v));
        opts.add(num("Multi-target count", () -> c.multiCount, v -> c.multiCount = v, new int[]{1, 2, 3, 4, 5, 6}));
        opts.add(num("Tracking range", () -> c.trackingRange, v -> c.trackingRange = v, new int[]{8, 16, 32, 64, 128}));

        opts.add(num("Combat timeout (s)", () -> c.combatTimeoutSec, v -> c.combatTimeoutSec = v, new int[]{3, 5, 8, 12, 20, 40}));
        opts.add(num("Data retention (min)", () -> c.retentionMinutes, v -> c.retentionMinutes = v, new int[]{5, 15, 30, 60, 240, 1440}));
        opts.add(bool("Persist between sessions", () -> c.persistData, v -> c.persistData = v));
        opts.add(num("Assumed Unbreaking", () -> c.assumedUnbreaking, v -> c.assumedUnbreaking = v, new int[]{0, 1, 2, 3}));
        opts.add(num("Assumed start cond. %", () -> c.startConditionPct, v -> c.startConditionPct = v, new int[]{100, 90, 75, 50}));
        opts.add(bool("Debug mode", () -> c.debug, v -> c.debug = v));
    }

    // ---- option factories
    private Opt bool(String l, BooleanSupplier g, Consumer<Boolean> s) {
        return new Opt(l, () -> g.getAsBoolean() ? "ON" : "OFF", () -> { s.accept(!g.getAsBoolean()); c.changed(); });
    }

    private <E extends Enum<E>> Opt en(String l, Supplier<E> g, Consumer<E> s, E[] vals) {
        return new Opt(l, () -> g.get().name().replace('_', ' '), () -> { s.accept(vals[(g.get().ordinal() + 1) % vals.length]); c.changed(); });
    }

    private Opt num(String l, IntSupplier g, IntConsumer s, int[] presets) {
        return new Opt(l, () -> String.valueOf(g.getAsInt()), () -> {
            int next = presets[0];
            for (int p : presets) if (p > g.getAsInt()) { next = p; break; }
            s.accept(next); c.changed();
        });
    }

    private Opt dbl(String l, DoubleSupplier g, DoubleConsumer s, double[] presets) {
        return new Opt(l, () -> String.valueOf(g.getAsDouble()), () -> {
            double next = presets[0];
            for (double p : presets) if (p > g.getAsDouble() + 1e-9) { next = p; break; }
            s.accept(next); c.changed();
        });
    }

    @Override
    protected void init() {
        int pages = (opts.size() + PER_PAGE - 1) / PER_PAGE;
        int start = page * PER_PAGE;
        int colW = 150, gap = 8, left = width / 2 - colW - gap / 2;
        for (int i = 0; i < PER_PAGE && start + i < opts.size(); i++) {
            Opt o = opts.get(start + i);
            int x = left + (i % 2) * (colW + gap);
            int y = 32 + (i / 2) * 24;
            addDrawableChild(ButtonWidget.builder(Text.literal(o.label() + ": " + o.value().get()), b -> {
                o.next().run();
                b.setMessage(Text.literal(o.label() + ": " + o.value().get()));
            }).dimensions(x, y, colW, 20).build());
        }
        int ny = 32 + 6 * 24 + 10;
        addDrawableChild(ButtonWidget.builder(Text.literal("< Prev"), b -> { page = (page + pages - 1) % pages; clearAndInit(); })
                .dimensions(width / 2 - 154, ny, 70, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Done"), b -> close())
                .dimensions(width / 2 - 40, ny, 80, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Next >"), b -> { page = (page + 1) % pages; clearAndInit(); })
                .dimensions(width / 2 + 84, ny, 70, 20).build());
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);
        ctx.drawCenteredTextWithShadow(textRenderer, Text.literal("Armor Estimator  (page " + (page + 1) + "/3)"), width / 2, 12, 0xFFFFFFFF);
        ctx.drawCenteredTextWithShadow(textRenderer, Text.literal("All values are ESTIMATES. Custom colors: config/armorest.json"),
                width / 2, 32 + 6 * 24 + 36, 0xFFAAAAAA);
    }

    @Override
    public void close() {
        c.save();
        if (client != null) client.setScreen(parent);
    }
}
