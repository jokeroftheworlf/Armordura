package com.example.armorest.track;

import com.example.armorest.ArmorEstClient;
import com.example.armorest.config.ModConfig;
import com.example.armorest.estimate.DurabilityEstimator;
import com.example.armorest.estimate.Params;
import com.example.armorest.model.*;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.util.hit.EntityHitResult;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;

/**
 * Event-driven combat tracker. Work happens (a) when WE hit a player and (b) once per client tick for the few
 * profiles that are in combat. No world scans per tick; the nearest-player scan runs twice per second.
 */
public final class TrackerManager {
    private static final EquipmentSlot[] SLOTS = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
    private static final Gson GSON = new GsonBuilder().create();

    private final ModConfig cfg;
    private final Params params = new Params();
    private final Map<UUID, OpponentProfile> profiles = new LinkedHashMap<>();
    private final List<OpponentProfile> displayBuf = new ArrayList<>(6);
    private long tick;
    private UUID lastHitId, manualId, nearestId, currentId;
    private long lastSwitchMs;

    public TrackerManager(ModConfig cfg) { this.cfg = cfg; }

    public Params params() { return params; }

    public void refreshParams() {
        params.assumedUnbreaking = cfg.assumedUnbreaking;
        params.startCondition = cfg.startConditionPct / 100.0;
        params.unknownArmorDurability = cfg.unknownArmorDurability;
        params.bump();
    }

    // ------------------------------------------------------------------ attack event

    public void onAttack(PlayerEntity self, PlayerEntity target) {
        if (!cfg.enabled || !cfg.trackingEnabled) return;
        if (target == self || target.isSpectator()) return;
        long now = System.currentTimeMillis();
        OpponentProfile pr = profile(target, now);
        syncArmor(pr, target, true);

        if (now - pr.lastCombatMs > cfg.combatTimeoutSec * 1000L) {
            if (pr.engagementStartMs > 0) pr.engagedTotalMs += pr.engagementMs();
            pr.engagementStartMs = now;
            pr.currentCombo = 0;
        }

        // What the client can legitimately observe about OUR attack (read before the attack resets the cooldown).
        ItemStack held = self.getMainHandStack();
        String itemId = Registries.ITEM.getId(held.getItem()).toString();
        double base = self.getAttributeValue(EntityAttributes.ATTACK_DAMAGE);
        WeaponCategory wc = WeaponCategory.classify(itemId, base);
        float cd = self.getAttackCooldownProgress(0.5F);
        boolean full = cd > 0.9F;
        double scale = 0.2 + cd * cd * 0.8;
        double fall = self.fallDistance;
        boolean smash = wc == WeaponCategory.MACE && fall > 1.5 && !self.isGliding();
        boolean crit = !smash && full && fall > 0 && !self.isOnGround() && !self.isClimbing()
                && !self.isTouchingWater() && !self.hasStatusEffect(StatusEffects.BLINDNESS)
                && !self.hasVehicle() && !self.isSprinting();
        AttackType type = smash ? AttackType.SMASH : crit ? AttackType.CRITICAL : AttackType.NORMAL;
        double raw = base * scale * (crit ? 1.5 : 1.0);
        if (smash) raw += maceBonus(fall) * cd;

        long dt = pr.lastHitMs == 0 ? 0 : now - pr.lastHitMs;
        if (pr.lastHitMs != 0 && dt <= cfg.comboWindowMs) pr.currentCombo++;
        else { pr.currentCombo = 1; pr.comboStartMs = now; }
        pr.highestCombo = Math.max(pr.highestCombo, pr.currentCombo);

        pr.hits++;
        switch (type) { case CRITICAL -> pr.crits++; case SMASH -> pr.smashes++; default -> pr.normals++; }
        pr.weaponCounts[wc.ordinal()]++;
        pr.lastWeapon = wc;
        pr.lastHitMs = pr.lastCombatMs = now;
        pr.staleMarked = false;
        lastHitId = target.getUuid();

        double hp = target.getHealth() + target.getAbsorptionAmount();
        if (pr.pending.size() < 16)
            pr.pending.addLast(new OpponentProfile.Pending(tick, now, hp, raw, type, wc, full, target.isBlocking(), pr.currentCombo, dt));
        if (Double.isNaN(pr.lastHp)) pr.lastHp = hp;

        if (cfg.debug) ArmorEstClient.debug(String.format(Locale.ROOT,
                "HIT %s uuid=%s %s %s cd=%.2f rawModel=%.2f combo=%d dt=%dms blocking=%s",
                pr.name, pr.uuid, type, wc, cd, raw, pr.currentCombo, dt, target.isBlocking()));
    }

    private static double maceBonus(double f) {
        if (f <= 3) return 4 * f;
        if (f <= 8) return 12 + 2 * (f - 3);
        return 22 + (f - 8);
    }

    // ------------------------------------------------------------------ tick

    public void onTick(MinecraftClient mc) {
        tick++;
        if (mc.world == null || mc.player == null || !cfg.enabled || !cfg.trackingEnabled) return;
        long now = System.currentTimeMillis();
        long timeoutMs = cfg.combatTimeoutSec * 1000L;

        for (OpponentProfile pr : profiles.values()) {
            boolean relevant = !pr.pending.isEmpty() || now - pr.lastCombatMs <= timeoutMs || pr.id().equals(currentId);
            if (!relevant) continue;
            PlayerEntity pl = mc.world.getPlayerByUuid(pr.id());
            if (pl == null) {
                if (pr.missingSinceMs == 0) pr.missingSinceMs = now;
                pr.lastHp = Double.NaN;
                continue;
            }
            if (pr.missingSinceMs != 0) {
                if (now - pr.missingSinceMs > 20_000 && pr.hits > 0) {
                    pr.estimator.markGap();
                    if (cfg.debug) ArmorEstClient.debug("GAP " + pr.name + " reappeared after " + (now - pr.missingSinceMs) / 1000 + "s");
                }
                pr.missingSinceMs = 0;
            }
            double hp = pl.getHealth() + pl.getAbsorptionAmount();
            boolean dropHandled = resolvePending(mc, pr, hp, now);
            if (!dropHandled && pr.pending.isEmpty() && !Double.isNaN(pr.lastHp) && pr.hits > 0
                    && pr.lastHp - hp >= 1.0) {
                pr.estimator.recordUnattributedDamage(pr.lastHp - hp);
                if (cfg.debug) ArmorEstClient.debug(String.format(Locale.ROOT,
                        "UNATTRIBUTED %s lost %.2f hp with no hit of ours (other attacker/source)", pr.name, pr.lastHp - hp));
            }
            pr.lastHp = hp;
        }

        if (tick % 10 == 0) periodic(mc, now);
        if (tick % 200 == 0) purge(now);
    }

    private boolean resolvePending(MinecraftClient mc, OpponentProfile pr, double hp, long now) {
        if (pr.pending.isEmpty()) return false;
        int window = 6;
        if (mc.getNetworkHandler() != null && mc.player != null) {
            PlayerListEntry e = mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid());
            if (e != null) window += Math.min(24, e.getLatency() / 50);
        }
        boolean dropHandled = false;
        while (!pr.pending.isEmpty()) {
            OpponentProfile.Pending pd = pr.pending.peekFirst();
            double dropped = pd.hpAtHit - hp;
            if (dropped > 0.01) {
                finishHit(pr, pd, dropped);
                pr.pending.pollFirst();
                for (OpponentProfile.Pending o : pr.pending) o.hpAtHit = hp;
                dropHandled = true;
            } else if (tick - pd.tick >= window) {
                finishHit(pr, pd, 0.0);
                pr.pending.pollFirst();
            } else break;
        }
        return dropHandled;
    }

    private void finishHit(OpponentProfile pr, OpponentProfile.Pending pd, double observed) {
        HitObservation ho = new HitObservation(pd.rawModel, observed, pd.blocking, pd.tick, pd.type, pd.weapon, pd.full);
        DurabilityEstimator.HitResult hr = pr.estimator.recordHit(ho, params);
        if (observed > 0) pr.damageDealt += observed;
        pr.addEvent(new CombatEvent(pr.uuid, pr.name, pd.timeMs, pd.rawModel, observed, pd.type, pd.weapon, pd.full,
                pd.streak, pd.sinceLastMs, pd.blocking, hr.reduced(), hr.outcome().name()));
        if (cfg.debug) {
            var r = pr.estimator.estimate(params);
            ArmorEstClient.debug(String.format(Locale.ROOT,
                    "RESOLVED %s observed=%.2f outcome=%s effRaw=%.2f fit=%s -> est ~%.1f%% [%.1f-%.1f] conf=%s(%.2f)",
                    pr.name, observed, hr.outcome(), hr.effectiveRaw(),
                    hr.fitChecked() ? (hr.consistent() ? "ok" : "MISMATCH") : "n/a",
                    r.conditionPct(), r.worstPct(), r.bestPct(), r.confidence().label(), r.confidenceScore()));
        }
    }

    private void periodic(MinecraftClient mc, long now) {
        long timeoutMs = cfg.combatTimeoutSec * 1000L;
        for (OpponentProfile pr : profiles.values()) {
            if (pr.hits > 0 && !pr.staleMarked && now - pr.lastCombatMs > cfg.staleMinutes * 60_000L) {
                pr.estimator.markGap();
                pr.staleMarked = true;
                if (cfg.debug) ArmorEstClient.debug("STALE " + pr.name + " idle > " + cfg.staleMinutes + "min: repairs possible");
            }
            if (now - pr.lastCombatMs <= timeoutMs || pr.id().equals(currentId)) {
                PlayerEntity pl = mc.world.getPlayerByUuid(pr.id());
                if (pl != null) { syncArmor(pr, pl, true); pr.lastTouchMs = now; }
            }
        }
        if (cfg.targetMode == ModConfig.TargetMode.NEAREST) {
            double best = (double) cfg.trackingRange * cfg.trackingRange;
            PlayerEntity found = null;
            for (PlayerEntity pl : mc.world.getPlayers()) {
                if (pl == mc.player || pl.isSpectator()) continue;
                double d = pl.squaredDistanceTo(mc.player);
                if (d <= best) { best = d; found = pl; }
            }
            if (found == null) nearestId = null;
            else {
                nearestId = found.getUuid();
                OpponentProfile pr = profile(found, now);
                syncArmor(pr, found, false);
            }
        }
    }

    private void purge(long now) {
        long ret = cfg.retentionMinutes * 60_000L;
        profiles.values().removeIf(pr -> now - Math.max(pr.lastTouchMs, pr.lastCombatMs) > ret
                && !pr.id().equals(manualId) && !pr.id().equals(currentId));
    }

    // ------------------------------------------------------------------ armor identity (item type only, never durability)

    private void syncArmor(OpponentProfile pr, PlayerEntity pl, boolean penalize) {
        String[] ids = new String[4];
        ArmorMaterialType[] mats = new ArmorMaterialType[4];
        for (int i = 0; i < 4; i++) {
            ItemStack st = pl.getEquippedStack(SLOTS[i]);
            if (st.isEmpty()) continue;
            String id = Registries.ITEM.getId(st.getItem()).toString();
            ArmorItems.Parsed parsed = ArmorItems.parse(id);
            if (parsed != null && parsed.slot() == ArmorSlot.VALUES[i]) { ids[i] = id; mats[i] = parsed.material(); }
        }
        if (!pr.armorInit) {
            pr.estimator.setInitialArmor(mats);
            pr.armorIds = ids;
            pr.armorInit = true;
            return;
        }
        for (int i = 0; i < 4; i++) {
            if (!Objects.equals(ids[i], pr.armorIds[i])) {
                if (penalize) pr.estimator.onArmorChanged(ArmorSlot.VALUES[i], mats[i]);
                else { pr.estimator.setInitialArmor(mats); }
                if (cfg.debug) ArmorEstClient.debug("ARMOR CHANGE " + pr.name + " " + ArmorSlot.VALUES[i] + ": "
                        + pr.armorIds[i] + " -> " + ids[i] + " (wear for slot reset)");
                pr.armorIds[i] = ids[i];
            }
        }
    }

    private OpponentProfile profile(PlayerEntity p, long now) {
        OpponentProfile pr = profiles.get(p.getUuid());
        if (pr == null) {
            pr = new OpponentProfile();
            pr.uuid = p.getUuidAsString();
            profiles.put(p.getUuid(), pr);
        }
        pr.name = p.getName().getString();
        pr.lastTouchMs = now;
        return pr;
    }

    // ------------------------------------------------------------------ target selection / HUD feed

    public List<OpponentProfile> displayTargets(MinecraftClient mc, long now) {
        displayBuf.clear();
        if (!cfg.enabled || !cfg.hudEnabled) return displayBuf;
        long timeoutMs = cfg.combatTimeoutSec * 1000L;

        if (cfg.targetMode == ModConfig.TargetMode.MULTI_TARGET) {
            for (OpponentProfile pr : profiles.values()) {
                if (pr.hits > 0 && (!cfg.onlyInCombat || now - pr.lastCombatMs <= timeoutMs + 1500)) displayBuf.add(pr);
            }
            displayBuf.sort((a, b) -> Long.compare(b.lastCombatMs, a.lastCombatMs));
            while (displayBuf.size() > cfg.multiCount) displayBuf.remove(displayBuf.size() - 1);
            return displayBuf;
        }

        UUID cand = null;
        switch (cfg.targetMode) {
            case MANUAL -> cand = manualId;
            case NEAREST -> cand = nearestId;
            case LAST_HIT -> cand = lastHitId;
            default -> { // AUTOMATIC: last engaged opponent, else whoever the crosshair is on
                OpponentProfile last = lastHitId == null ? null : profiles.get(lastHitId);
                if (last != null && now - last.lastCombatMs <= timeoutMs) cand = lastHitId;
                else if (mc.crosshairTarget instanceof EntityHitResult ehr && ehr.getEntity() instanceof PlayerEntity pl
                        && profiles.containsKey(pl.getUuid())) cand = pl.getUuid();
                else if (!cfg.onlyInCombat) cand = lastHitId;
            }
        }
        if (!Objects.equals(cand, currentId)) {
            boolean currentGone = currentId == null || !profiles.containsKey(currentId);
            if (cand == null || currentGone || now - lastSwitchMs >= cfg.targetSwitchDelayMs) {
                currentId = cand;
                lastSwitchMs = now;
            }
        }
        OpponentProfile cur = currentId == null ? null : profiles.get(currentId);
        if (cur != null) displayBuf.add(cur);
        return displayBuf;
    }

    /** 0..1 visibility based on combat age (HUD hides / fades after combat). */
    public float visibility(OpponentProfile pr, long now) {
        if (!cfg.onlyInCombat) return 1f;
        long age = now - pr.lastCombatMs;
        long t = cfg.combatTimeoutSec * 1000L;
        if (age <= t) return 1f;
        if (!cfg.fadeAfterCombat) return 0f;
        return Math.max(0f, 1f - (age - t) / 1500f);
    }

    public int comboNow(OpponentProfile pr, long now) {
        return (pr.lastHitMs != 0 && now - pr.lastHitMs <= cfg.comboWindowMs) ? pr.currentCombo : 0;
    }

    // ------------------------------------------------------------------ user actions

    public OpponentProfile find(MinecraftClient mc, String name) {
        for (OpponentProfile pr : profiles.values()) if (pr.name.equalsIgnoreCase(name)) return pr;
        if (mc.world != null) for (PlayerEntity pl : mc.world.getPlayers())
            if (pl != mc.player && pl.getName().getString().equalsIgnoreCase(name)) return profile(pl, System.currentTimeMillis());
        return null;
    }

    public OpponentProfile current() { return currentId == null ? null : profiles.get(currentId); }

    public void selectManual(OpponentProfile pr) {
        manualId = pr.id();
        currentId = manualId;
        lastSwitchMs = System.currentTimeMillis();
        cfg.targetMode = ModConfig.TargetMode.MANUAL;
        cfg.changed();
    }

    public void selectAutomatic() {
        manualId = null;
        cfg.targetMode = ModConfig.TargetMode.AUTOMATIC;
        cfg.changed();
    }

    public OpponentProfile selectCrosshair(MinecraftClient mc) {
        if (mc.crosshairTarget instanceof EntityHitResult ehr && ehr.getEntity() instanceof PlayerEntity pl && pl != mc.player) {
            OpponentProfile pr = profile(pl, System.currentTimeMillis());
            syncArmor(pr, pl, false);
            selectManual(pr);
            return pr;
        }
        return null;
    }

    public void cycleTarget() {
        List<OpponentProfile> all = new ArrayList<>(profiles.values());
        if (all.isEmpty()) return;
        int idx = -1;
        for (int i = 0; i < all.size(); i++) if (all.get(i).id().equals(currentId)) idx = i;
        selectManual(all.get((idx + 1) % all.size()));
    }

    public boolean remove(OpponentProfile pr) {
        if (pr.id().equals(currentId)) currentId = null;
        if (pr.id().equals(manualId)) manualId = null;
        if (pr.id().equals(lastHitId)) lastHitId = null;
        return profiles.remove(pr.id()) != null;
    }

    public void reset(OpponentProfile pr) {
        OpponentProfile fresh = new OpponentProfile();
        fresh.uuid = pr.uuid;
        fresh.name = pr.name;
        fresh.lastTouchMs = System.currentTimeMillis();
        profiles.put(pr.id(), fresh);
    }

    public void clearAll() {
        profiles.clear();
        lastHitId = manualId = nearestId = currentId = null;
    }

    public Collection<OpponentProfile> all() { return profiles.values(); }

    // ------------------------------------------------------------------ session / persistence

    private static Path dataPath() { return FabricLoader.getInstance().getConfigDir().resolve("armorest-data.json"); }

    public void onJoin() {
        clearAll();
        if (!cfg.persistData) return;
        try {
            Path p = dataPath();
            if (!Files.exists(p)) return;
            Map<String, OpponentProfile> m = GSON.fromJson(Files.readString(p),
                    new TypeToken<LinkedHashMap<String, OpponentProfile>>() {}.getType());
            if (m == null) return;
            long now = System.currentTimeMillis();
            long ret = cfg.retentionMinutes * 60_000L;
            for (OpponentProfile pr : m.values()) {
                if (pr == null || pr.uuid == null || pr.estimator == null) continue;
                if (now - Math.max(pr.lastTouchMs, pr.lastCombatMs) > ret) continue;
                if (pr.weaponCounts == null || pr.weaponCounts.length != WeaponCategory.VALUES.length)
                    pr.weaponCounts = new int[WeaponCategory.VALUES.length];
                if (pr.armorIds == null || pr.armorIds.length != 4) pr.armorIds = new String[4];
                pr.estimator.markGap(); // we were not watching between sessions
                profiles.put(pr.id(), pr);
            }
        } catch (Exception e) {
            ArmorEstClient.LOG.warn("Could not load tracking data", e);
        }
    }

    public void onDisconnect() {
        saveIfEnabled();
        clearAll();
    }

    public void saveIfEnabled() {
        if (!cfg.persistData) return;
        try {
            Map<String, OpponentProfile> m = new LinkedHashMap<>();
            for (OpponentProfile pr : profiles.values()) m.put(pr.uuid, pr);
            Files.writeString(dataPath(), GSON.toJson(m));
        } catch (Exception e) {
            ArmorEstClient.LOG.warn("Could not save tracking data", e);
        }
    }
}
