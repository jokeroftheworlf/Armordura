package com.example.armorest.model;

public enum AttackType {
    NORMAL, CRITICAL, SMASH
}
