package com.example.armorest.estimate;

/** Tunable model parameters. Bump {@link #version} after changing anything so cached estimates refresh. */
public final class Params {
    public int version = 0;
    /** Unbreaking level assumed for the central estimate (0-3). Bounds always use 3 (best) and 0 (worst). */
    public int assumedUnbreaking = 2;
    /** Assumed condition (0..1) of armor when we first saw it. Unknowable, so it is an assumption. */
    public double startCondition = 1.0;
    /** Generic max durability used for armor pieces whose material is unknown. */
    public double unknownArmorDurability = 400;
    /** Below this many damaging hits the HUD shows "insufficient data". */
    public int minHitsForColor = 3;
    /** Confidence factor reflecting that the starting condition is never known. */
    public double startConfidence = 0.85;

    public void bump() { version++; }
}
