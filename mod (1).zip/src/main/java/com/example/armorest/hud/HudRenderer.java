package com.example.armorest.hud;

import com.example.armorest.ArmorEstClient;
import com.example.armorest.config.ModConfig;
import com.example.armorest.estimate.EstimateResult;
import com.example.armorest.model.ArmorSlot;
import com.example.armorest.track.OpponentProfile;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Compact PvP HUD. Panels are rebuilt only when their inputs change (cached per profile). */
public final class HudRenderer {
    private static final int LINE_H = 10, PAD = 3, GAP = 5, MIN_BAR_W = 90;

    private static final class Item {
        final String text; final int rgb; final int width; final boolean bar; final double cond, best;
        Item(String text, int rgb, int width) { this.text = text; this.rgb = rgb; this.width = width; bar = false; cond = best = 0; }
        Item(double cond, double best, int rgb) { text = ""; this.rgb = rgb; width = MIN_BAR_W; bar = true; this.cond = cond; this.best = best; }
    }

    private static final class Panel {
        Item[] items; int w, h; boolean horizontal;
    }

    private HudRenderer() {}

    public static void render(DrawContext ctx, RenderTickCounter tickCounter) {
        MinecraftClient mc = MinecraftClient.getInstance();
        ModConfig cfg = ArmorEstClient.CONFIG;
        if (cfg == null || !cfg.enabled || !cfg.hudEnabled || mc.player == null || mc.options.hudHidden
                || mc.currentScreen != null) return;
        long now = System.currentTimeMillis();
        List<OpponentProfile> targets = ArmorEstClient.TRACKER.displayTargets(mc, now);
        if (targets.isEmpty()) return;

        TextRenderer tr = mc.textRenderer;
        List<Panel> panels = new ArrayList<>(targets.size());
        List<Float> vis = new ArrayList<>(targets.size());
        int totalH = 0, maxW = 0;
        for (OpponentProfile pr : targets) {
            float v = ArmorEstClient.TRACKER.visibility(pr, now);
            if (v <= 0f) continue;
            Panel p = panelFor(pr, tr, cfg, now);
            panels.add(p); vis.add(v);
            totalH += p.h + (panels.size() > 1 ? GAP : 0);
            maxW = Math.max(maxW, p.w);
        }
        if (panels.isEmpty()) return;

        float s = (float) cfg.hudScale;
        float sw = ctx.getScaledWindowWidth(), sh = ctx.getScaledWindowHeight();
        float px = switch (cfg.anchor) {
            case TOP_LEFT, MIDDLE_LEFT, BOTTOM_LEFT -> cfg.offsetX;
            default -> sw - maxW * s + cfg.offsetX;
        };
        float py = switch (cfg.anchor) {
            case TOP_LEFT, TOP_RIGHT -> cfg.offsetY;
            case MIDDLE_LEFT, MIDDLE_RIGHT -> (sh - totalH * s) / 2f + cfg.offsetY;
            default -> sh - totalH * s + cfg.offsetY;
        };

        ctx.getMatrices().pushMatrix();
        ctx.getMatrices().translate(px, py);
        ctx.getMatrices().scale(s, s);
        int y = 0;
        for (int i = 0; i < panels.size(); i++) {
            draw(ctx, tr, panels.get(i), y, (float) (cfg.hudOpacity * vis.get(i)), cfg);
            y += panels.get(i).h + GAP;
        }
        ctx.getMatrices().popMatrix();
    }

    // ------------------------------------------------------------------ building (cached)

    private static Panel panelFor(OpponentProfile pr, TextRenderer tr, ModConfig cfg, long now) {
        EstimateResult r = pr.estimator.estimate(ArmorEstClient.TRACKER.params());
        int combo = ArmorEstClient.TRACKER.comboNow(pr, now);
        long key = ((long) System.identityHashCode(r) << 24) ^ (cfg.version * 1315423911L) ^ (pr.hits * 31L)
                ^ (pr.crits * 17L) ^ (combo * 7L) ^ Double.doubleToLongBits(pr.damageDealt) ^ pr.name.hashCode();
        if (pr.hudCache instanceof Panel p && pr.hudKey == key) return p;
        Panel p = build(pr, r, combo, tr, cfg);
        pr.hudCache = p;
        pr.hudKey = key;
        return p;
    }

    private static Panel build(OpponentProfile pr, EstimateResult r, int combo, TextRenderer tr, ModConfig cfg) {
        int[] pal = cfg.palette();
        int rgb;
        if (r.insufficient()) rgb = pal[4];
        else rgb = switch (r.category()) {
            case GOOD -> pal[0]; case WORN -> pal[1]; case HEAVY -> pal[2]; case CRITICAL -> pal[3]; default -> pal[4];
        };
        int confRgb = switch (r.confidence()) {
            case HIGH -> pal[0]; case MODERATE -> pal[1]; case LOW -> pal[2]; default -> pal[4];
        };

        List<Item> items = new ArrayList<>();
        items.add(text(tr, "TARGET: " + pr.name, 0xFFFFFF));

        if (!r.hasData()) items.add(text(tr, "EST. ARMOR: NO DATA", pal[4]));
        else if (r.noArmor()) items.add(text(tr, "NO ARMOR WORN", pal[4]));
        else {
            String c = "EST. ARMOR ~" + Math.round(r.conditionPct()) + "%";
            if (cfg.showRange) c += " (" + Math.round(r.worstPct()) + "-" + Math.round(r.bestPct()) + ")";
            items.add(text(tr, c, rgb));
            items.add(new Item(r.conditionPct(), r.bestPct(), rgb));
            if (cfg.showWear) items.add(text(tr, "EST. WEAR ~" + Math.round(r.wearPct()) + "%", rgb));
        }
        if (cfg.showConfidence) {
            int pips = r.confidence().ordinal() + 1;
            items.add(text(tr, "CONF: " + r.confidence().label() + " [" + "#".repeat(pips) + ".".repeat(4 - pips) + "]", confRgb));
        }
        if (cfg.showHits) items.add(text(tr, "HITS: " + pr.hits, 0xFFFFFF));
        if (cfg.showCrits) items.add(text(tr, "CRITS: " + pr.crits, 0xFFFFFF));
        if (cfg.showDamage) items.add(text(tr, String.format(Locale.ROOT, "DMG: %.1f", pr.damageDealt), 0xFFFFFF));
        if (cfg.showCombo) items.add(text(tr, "COMBO: " + combo, 0xFFFFFF));
        if (cfg.showPieces && r.hasData() && !r.noArmor()) {
            StringBuilder sb = new StringBuilder();
            for (EstimateResult.SlotEstimate se : r.slots()) {
                if (se.material() == null) continue;
                sb.append(se.slot().shortName()).append(se.material().isKnown() ? "~" : "?~")
                        .append(Math.round(se.conditionPct())).append(' ');
            }
            items.add(text(tr, sb.toString().trim(), 0xCCCCCC));
        }

        Panel p = new Panel();
        p.items = items.toArray(new Item[0]);
        p.horizontal = cfg.layout == ModConfig.Layout.HORIZONTAL;
        int w = 0, h = 0;
        if (p.horizontal) {
            for (Item it : p.items) w += (it.bar ? 50 : it.width) + 6;
            w += 2 * PAD - 6;
            h = LINE_H + 2 * PAD - 2;
        } else {
            int barH = cfg.barStyle == ModConfig.BarStyle.THIN ? 3 : 5;
            for (Item it : p.items) {
                w = Math.max(w, it.width);
                h += it.bar ? barH + 3 : LINE_H;
            }
            w += 2 * PAD;
            h += 2 * PAD - 1;
        }
        p.w = w; p.h = h;
        return p;
    }

    private static Item text(TextRenderer tr, String s, int rgb) { return new Item(s, rgb, tr.getWidth(s)); }

    // ------------------------------------------------------------------ drawing

    private static int argb(float alpha, int rgb) {
        int a = Math.max(26, Math.min(255, Math.round(alpha * 255f)));
        return (a << 24) | (rgb & 0xFFFFFF);
    }

    private static int dim(int rgb) {
        return (((rgb >> 16 & 0xFF) / 2) << 16) | (((rgb >> 8 & 0xFF) / 2) << 8) | ((rgb & 0xFF) / 2);
    }

    private static void draw(DrawContext ctx, TextRenderer tr, Panel p, int y0, float alpha, ModConfig cfg) {
        ctx.fill(0, y0, p.w, y0 + p.h, argb(alpha * 0.45f, 0x000000));
        int barH = cfg.barStyle == ModConfig.BarStyle.THIN ? 3 : 5;
        if (p.horizontal) {
            int x = PAD, ty = y0 + PAD;
            for (Item it : p.items) {
                if (it.bar) { drawBar(ctx, x, ty + 2, 50, barH, it, alpha, cfg.barStyle); x += 50 + 6; }
                else { ctx.drawTextWithShadow(tr, it.text, x, ty, argb(alpha, it.rgb)); x += it.width + 6; }
            }
        } else {
            int y = y0 + PAD;
            for (Item it : p.items) {
                if (it.bar) { drawBar(ctx, PAD, y + 1, p.w - 2 * PAD, barH, it, alpha, cfg.barStyle); y += barH + 3; }
                else { ctx.drawTextWithShadow(tr, it.text, PAD, y, argb(alpha, it.rgb)); y += LINE_H; }
            }
        }
    }

    /** Dark track, dim fill up to the best plausible condition, bright fill up to the central estimate. */
    private static void drawBar(DrawContext ctx, int x, int y, int w, int h, Item it, float alpha, ModConfig.BarStyle style) {
        int track = argb(alpha, 0x303030), dimC = argb(alpha, dim(it.rgb)), full = argb(alpha, it.rgb);
        double cond = Math.max(0, Math.min(1, it.cond / 100.0)), best = Math.max(cond, Math.min(1, it.best / 100.0));
        if (style == ModConfig.BarStyle.SEGMENTED) {
            int segs = 10, gap = 1, sw = Math.max(1, (w - gap * (segs - 1)) / segs);
            for (int i = 0; i < segs; i++) {
                int sx = x + i * (sw + gap);
                double lo = i / (double) segs, hi = (i + 1) / (double) segs;
                ctx.fill(sx, y, sx + sw, y + h, track);
                fillPart(ctx, sx, y, sw, h, lo, hi, best, dimC);
                fillPart(ctx, sx, y, sw, h, lo, hi, cond, full);
            }
        } else {
            ctx.fill(x, y, x + w, y + h, track);
            ctx.fill(x, y, x + (int) Math.round(w * best), y + h, dimC);
            ctx.fill(x, y, x + (int) Math.round(w * cond), y + h, full);
        }
    }

    private static void fillPart(DrawContext ctx, int sx, int y, int sw, int h, double lo, double hi, double v, int color) {
        if (v <= lo) return;
        double f = Math.min(1.0, (v - lo) / (hi - lo));
        ctx.fill(sx, y, sx + (int) Math.round(sw * f), y + h, color);
    }
}
