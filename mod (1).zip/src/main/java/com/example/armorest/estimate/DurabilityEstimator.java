package com.example.armorest.estimate;

import com.example.armorest.estimate.EstimateResult.Category;
import com.example.armorest.estimate.EstimateResult.SlotEstimate;
import com.example.armorest.model.*;

import java.util.ArrayList;
import java.util.List;

/**
 * Statistical armor-wear model for ONE opponent. No Minecraft types, so it is unit-testable.
 *
 * Model (vanilla Java Edition): when armor-affecting damage D (pre-armor, after shield and invulnerability-frame
 * reduction) is applied, EVERY worn armor piece loses max(1, floor(D/4)) durability points. Unbreaking is unknown, so
 * each point lands with probability 0.6+0.4/(L+1). We keep three accumulators per slot:
 *   central (assumed Unbreaking level, modelled D), best case (Unbreaking III, lower D), worst case (no Unbreaking, higher D).
 */
public final class DurabilityEstimator {
    public static final int IFRAME_TICKS = 10;

    public enum Outcome { APPLIED, NO_DAMAGE, BLOCKED, ASSUMED_APPLIED }

    public record HitResult(Outcome outcome, double effectiveRaw, boolean reduced, boolean fitChecked, boolean consistent) {}

    private ArmorMaterialType[] mat = new ArmorMaterialType[4]; // null = empty slot
    private double[] lossC = new double[4], lossMin = new double[4], lossMax = new double[4], extraMax = new double[4];
    private int effectiveHits, noDamageHits, blockedHits, observedHits, unobservedHits;
    private int consistentHits, inconsistentHits, armorChanges, gaps, otherDamageEvents;
    private double observedDamage;
    private double lastAppliedRaw;
    private long lastAppliedTick = -1_000_000L;
    private transient EstimateResult cached;
    private transient int cachedVersion = -1;

    // ---------------------------------------------------------------- armor bookkeeping

    /** First sighting of the target's armor: no confidence penalty. */
    public void setInitialArmor(ArmorMaterialType[] snapshot) {
        for (int i = 0; i < 4; i++) mat[i] = snapshot[i];
        cached = null;
    }

    /** A slot's item identity changed: wear for that slot is no longer valid. */
    public void onArmorChanged(ArmorSlot slot, ArmorMaterialType newMat) {
        int i = slot.ordinal();
        mat[i] = newMat;
        lossC[i] = lossMin[i] = lossMax[i] = extraMax[i] = 0;
        armorChanges++;
        cached = null;
    }

    /** Tracking was interrupted (rejoin, long idle, data reload): repairs/swaps may have happened. */
    public void markGap() { gaps++; cached = null; }

    public ArmorMaterialType materialAt(ArmorSlot s) { return mat[s.ordinal()]; }

    // ---------------------------------------------------------------- hit recording

    public HitResult recordHit(HitObservation o, Params p) {
        cached = null;
        boolean observed = !Double.isNaN(o.observedPost());
        if (observed) observedHits++; else unobservedHits++;

        if (observed && o.observedPost() < 0.01) {
            if (o.blocking()) blockedHits++; else noDamageHits++;
            return new HitResult(o.blocking() ? Outcome.BLOCKED : Outcome.NO_DAMAGE, 0, o.blocking(), false, true);
        }
        if (!observed && o.blocking()) {
            blockedHits++;
            return new HitResult(Outcome.BLOCKED, 0, true, false, true);
        }

        double armor = 0, tough = 0;
        boolean armorKnown = true;
        for (int i = 0; i < 4; i++) {
            if (mat[i] == null) continue;
            if (!mat[i].isKnown()) { armorKnown = false; continue; }
            armor += mat[i].defense(ArmorSlot.VALUES[i]);
            tough += mat[i].toughness();
        }

        long since = o.tick() - lastAppliedTick;
        boolean iframe = since >= 0 && since < IFRAME_TICKS;
        double eff = iframe ? Math.max(0, o.rawModel() - lastAppliedRaw) : o.rawModel();

        boolean fitChecked = false, consistent = true, reduced = false;
        if (observed) {
            double obs = o.observedPost();
            if (armorKnown) {
                double predicted = DamageMath.afterArmor(eff, armor, tough);
                fitChecked = true;
                if (obs > predicted * 1.12 + 0.25) {
                    // More damage got through than modelled (e.g. unmodelled Sharpness): trust the observation upward.
                    eff = Math.max(eff, DamageMath.invertAfterArmor(obs, armor, tough));
                    consistent = false;
                } else if (obs < predicted * 0.5) {
                    consistent = false; // Protection / Resistance / partial absorption: reduced hit
                    reduced = true;
                }
                if (consistent) consistentHits++; else inconsistentHits++;
            } else if (eff <= 0) {
                eff = obs; // armor unknown and the model claims i-frames absorbed it: use observation as lower bound
            }
        } else if (iframe && eff <= 0) {
            noDamageHits++;
            return new HitResult(Outcome.NO_DAMAGE, 0, false, false, true);
        }
        if (eff <= 0) { noDamageHits++; return new HitResult(Outcome.NO_DAMAGE, 0, false, fitChecked, consistent); }

        // ---- wear accumulation
        double highF = (armorKnown && observed) ? 1.12 : 1.30;
        double lowF = switch (o.type()) { case CRITICAL -> 0.80; case SMASH -> 0.70; default -> 0.90; };
        if (o.type() == AttackType.SMASH) highF = Math.max(highF, 1.35);
        int nC = DamageMath.durabilityPerPiece(eff);
        int nL = DamageMath.durabilityPerPiece(eff * lowF);
        int nH = DamageMath.durabilityPerPiece(eff * highF);
        double uC = DamageMath.armorUseChance(clampLevel(p.assumedUnbreaking));
        double uL = DamageMath.armorUseChance(3);
        double uH = DamageMath.armorUseChance(0);
        for (int i = 0; i < 4; i++) {
            if (mat[i] == null) continue;
            lossC[i] += nC * uC;
            lossMin[i] += nL * uL;
            lossMax[i] += nH * uH;
        }
        effectiveHits++;
        if (observed) observedDamage += o.observedPost();

        if (iframe) {
            lastAppliedRaw = lastAppliedRaw + eff; // vanilla: lastDamage becomes the new (larger) raw amount; timer not reset
        } else {
            lastAppliedTick = o.tick();
            lastAppliedRaw = eff;
        }
        return new HitResult(observed ? Outcome.APPLIED : Outcome.ASSUMED_APPLIED, eff, reduced, fitChecked, consistent);
    }

    /** Health dropped with no hit of ours to explain it (another player, fall damage, ...). Only widens the worst case. */
    public void recordUnattributedDamage(double post) {
        if (post <= 0) return;
        cached = null;
        otherDamageEvents++;
        double armor = 0, tough = 0;
        boolean known = true;
        for (int i = 0; i < 4; i++) {
            if (mat[i] == null) continue;
            if (!mat[i].isKnown()) { known = false; continue; }
            armor += mat[i].defense(ArmorSlot.VALUES[i]);
            tough += mat[i].toughness();
        }
        double raw = known ? DamageMath.invertAfterArmor(post, armor, tough) : post * 1.5;
        int n = DamageMath.durabilityPerPiece(raw * 1.15);
        for (int i = 0; i < 4; i++) if (mat[i] != null) extraMax[i] += n;
    }

    private static int clampLevel(int l) { return Math.max(0, Math.min(3, l)); }

    public int effectiveHits() { return effectiveHits; }
    public double observedDamage() { return observedDamage; }

    // ---------------------------------------------------------------- estimate

    public EstimateResult estimate(Params p) {
        if (cached != null && cachedVersion == p.version) return cached;

        SlotEstimate[] slots = new SlotEstimate[4];
        double sumMax = 0, sumC = 0, sumBest = 0, sumWorst = 0;
        int present = 0, known = 0;
        for (int i = 0; i < 4; i++) {
            ArmorSlot s = ArmorSlot.VALUES[i];
            if (mat[i] == null) { slots[i] = new SlotEstimate(s, null, 0, 0, 0, 0); continue; }
            present++;
            double maxD = mat[i].isKnown() ? mat[i].maxDurability(s)
                    : p.unknownArmorDurability * s.baseDurability() / 13.75;
            if (mat[i].isKnown()) known++;
            double c = frac(p.startCondition - lossC[i] / maxD);
            double best = frac(p.startCondition - lossMin[i] / maxD);
            double worst = frac(p.startCondition - (lossMax[i] + extraMax[i]) / maxD);
            slots[i] = new SlotEstimate(s, mat[i], c * 100, worst * 100, best * 100, maxD);
            sumMax += maxD; sumC += c * maxD; sumBest += best * maxD; sumWorst += worst * maxD;
        }
        boolean noArmor = present == 0;
        boolean hasData = effectiveHits > 0;
        double cond = noArmor ? 0 : sumC / sumMax * 100;
        double best = noArmor ? 0 : sumBest / sumMax * 100;
        double worst = noArmor ? 0 : sumWorst / sumMax * 100;
        if (!noArmor && !hasData) { cond = best = worst = p.startCondition * 100; }

        // ---- confidence (explainable factors)
        List<String> notes = new ArrayList<>();
        double evidence = 1 - Math.exp(-effectiveHits / 10.0);
        double armorKnow = present == 0 ? 1.0 : (double) known / present;
        int totalObs = observedHits + unobservedHits;
        double dmgObs = totalObs == 0 ? 0 : (double) observedHits / totalObs;
        double fit = (consistentHits + inconsistentHits) == 0 ? 0.6 : (double) consistentHits / (consistentHits + inconsistentHits);
        double interval = noArmor ? 1 : Math.max(0, Math.min(1, 1 - (best - worst) / 100.0 / 0.30));
        double session = 1.0 / (1.0 + 0.4 * armorChanges + 0.25 * gaps + 0.15 * otherDamageEvents);
        double mean = (3 * evidence + 2 * armorKnow + 2 * dmgObs + 1 * fit + 2 * interval + 2 * session + 1 * p.startConfidence) / 13.0;
        double score = hasData ? mean * (0.25 + 0.75 * evidence) : 0;
        if (!noArmor && hasData && cond <= 1.0) {
            score *= 0.5; // model says the armor should already have broken: it was likely repaired/replaced
            notes.add("Estimate hit 0%: armor was probably repaired or replaced");
        }
        score = Math.max(0, Math.min(1, score));
        Confidence conf = Confidence.fromScore(score);

        if (!hasData) notes.add("No damaging hits observed yet");
        else if (evidence < 0.7) notes.add("Few observations (" + effectiveHits + " damaging hits)");
        if (armorKnow < 1) notes.add("Armor material unknown on " + (present - known) + " slot(s)");
        if (totalObs > 0 && dmgObs < 0.8) notes.add("Damage could not be observed for some hits");
        if (fit < 0.7 && consistentHits + inconsistentHits > 0) notes.add("Observed damage often disagrees with the model");
        if (armorChanges > 0) notes.add("Target changed armor " + armorChanges + "x (wear reset for those slots)");
        if (gaps > 0) notes.add("Tracking interrupted " + gaps + "x (rejoin/idle: repairs possible)");
        if (otherDamageEvents > 0) notes.add(otherDamageEvents + " damage event(s) from unknown sources");
        if (interval < 0.7 && hasData) notes.add("Wide plausible range (Unbreaking/Mending unknown)");

        String quality;
        if (!hasData) quality = "NONE";
        else {
            double q = (dmgObs + fit) / 2.0;
            quality = q >= 0.8 ? "GOOD" : q >= 0.5 ? "FAIR" : "POOR";
        }

        List<String> unknowns = new ArrayList<>();
        unknowns.add("Target's Unbreaking / Mending / repairs");
        unknowns.add("Durability of the armor before tracking began");
        unknowns.add("Protection enchants (affect damage taken, not wear)");
        if (armorKnow < 1) unknowns.add("Material of " + (present - known) + " armor piece(s)");
        if (otherDamageEvents > 0) unknowns.add("Damage from other players/sources");

        List<String> assumptions = new ArrayList<>();
        assumptions.add("Every worn piece loses max(1, floor(damage/4)) per damaging hit");
        assumptions.add("Central estimate assumes Unbreaking " + clampLevel(p.assumedUnbreaking) + "; range spans III..none");
        assumptions.add("Armor started at " + Math.round(p.startCondition * 100) + "% when first seen");
        assumptions.add("Crits/smashes are predicted from client state, not confirmed");

        Category cat;
        boolean insufficient = !hasData || effectiveHits < p.minHitsForColor || conf == Confidence.VERY_LOW;
        if (!hasData || noArmor) cat = Category.NO_DATA;
        else if (cond >= 70) cat = Category.GOOD;
        else if (cond >= 45) cat = Category.WORN;
        else if (cond >= 20) cat = Category.HEAVY;
        else cat = Category.CRITICAL;

        cached = new EstimateResult(hasData, noArmor, insufficient, cond, worst, best, noArmor ? 0 : 100 - cond,
                cat, conf, score, quality, slots, notes, unknowns, assumptions, effectiveHits);
        cachedVersion = p.version;
        return cached;
    }

    private static double frac(double v) { return Math.max(0, Math.min(1, v)); }
}
