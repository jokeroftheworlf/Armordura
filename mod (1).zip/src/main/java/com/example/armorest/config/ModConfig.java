package com.example.armorest.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;

/** Persistent settings (config/armorest.json). Edit the file for custom colors; everything else is in the in-game menu. */
public final class ModConfig {
    public enum TargetMode { AUTOMATIC, MANUAL, NEAREST, LAST_HIT, MULTI_TARGET }
    public enum Anchor { TOP_LEFT, TOP_RIGHT, MIDDLE_LEFT, MIDDLE_RIGHT, BOTTOM_LEFT, BOTTOM_RIGHT }
    public enum Layout { VERTICAL, HORIZONTAL }
    public enum BarStyle { SOLID, SEGMENTED, THIN }
    public enum Scheme { DEFAULT, COLORBLIND, MONO, CUSTOM }

    public boolean enabled = true, hudEnabled = true, trackingEnabled = true;
    public TargetMode targetMode = TargetMode.AUTOMATIC;
    public Anchor anchor = Anchor.MIDDLE_LEFT;
    public int offsetX = 6, offsetY = -40;
    public double hudScale = 1.0, hudOpacity = 0.9;
    public Layout layout = Layout.VERTICAL;
    public BarStyle barStyle = BarStyle.SOLID;
    public Scheme colorScheme = Scheme.DEFAULT;
    public boolean showWear = true, showConfidence = true, showHits = true, showCrits = true,
            showDamage = true, showCombo = true, showRange = true, showPieces = false;
    public boolean onlyInCombat = true, fadeAfterCombat = true;
    public int multiCount = 3;
    public int trackingRange = 32;
    public int combatTimeoutSec = 8;
    public int comboWindowMs = 1500;
    public int targetSwitchDelayMs = 400;
    public boolean persistData = false;
    public int retentionMinutes = 30;
    public int staleMinutes = 5;
    public int assumedUnbreaking = 2;
    public int startConditionPct = 100;
    public int unknownArmorDurability = 400;
    public boolean debug = false;
    public String customGood = "#55FF55", customWarn = "#FFFF55", customOrange = "#FFAA00",
            customBad = "#FF5555", customNoData = "#AAAAAA";

    public transient int version = 1;
    public transient Runnable onChange;
    private transient int[] palette;

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    private static Path path() { return FabricLoader.getInstance().getConfigDir().resolve("armorest.json"); }

    public static ModConfig load() {
        ModConfig c = null;
        try {
            Path p = path();
            if (Files.exists(p)) c = GSON.fromJson(Files.readString(p), ModConfig.class);
        } catch (Exception ignored) { }
        if (c == null) c = new ModConfig();
        c.sanitize();
        c.save();
        return c;
    }

    public void save() {
        try { Files.writeString(path(), GSON.toJson(this)); } catch (Exception ignored) { }
    }

    /** Call after any setting changed. */
    public void changed() {
        sanitize();
        version++;
        palette = null;
        save();
        if (onChange != null) onChange.run();
    }

    private void sanitize() {
        if (targetMode == null) targetMode = TargetMode.AUTOMATIC;
        if (anchor == null) anchor = Anchor.MIDDLE_LEFT;
        if (layout == null) layout = Layout.VERTICAL;
        if (barStyle == null) barStyle = BarStyle.SOLID;
        if (colorScheme == null) colorScheme = Scheme.DEFAULT;
        hudScale = Math.max(0.5, Math.min(3.0, hudScale));
        hudOpacity = Math.max(0.1, Math.min(1.0, hudOpacity));
        multiCount = Math.max(1, Math.min(6, multiCount));
        trackingRange = Math.max(4, Math.min(128, trackingRange));
        combatTimeoutSec = Math.max(1, Math.min(120, combatTimeoutSec));
        comboWindowMs = Math.max(200, Math.min(10000, comboWindowMs));
        targetSwitchDelayMs = Math.max(0, Math.min(5000, targetSwitchDelayMs));
        retentionMinutes = Math.max(1, Math.min(1440, retentionMinutes));
        staleMinutes = Math.max(1, Math.min(120, staleMinutes));
        assumedUnbreaking = Math.max(0, Math.min(3, assumedUnbreaking));
        startConditionPct = Math.max(1, Math.min(100, startConditionPct));
        unknownArmorDurability = Math.max(50, Math.min(1000, unknownArmorDurability));
        if (customGood == null) customGood = "#55FF55";
        if (customWarn == null) customWarn = "#FFFF55";
        if (customOrange == null) customOrange = "#FFAA00";
        if (customBad == null) customBad = "#FF5555";
        if (customNoData == null) customNoData = "#AAAAAA";
    }

    /** RGB colors: good, warn, orange, bad, no-data. */
    public int[] palette() {
        if (palette == null) {
            palette = switch (colorScheme) {
                case COLORBLIND -> new int[]{0x56B4E9, 0xF0E442, 0xE69F00, 0xD55E00, 0xAAAAAA};
                case MONO -> new int[]{0xFFFFFF, 0xDDDDDD, 0xBBBBBB, 0x999999, 0x777777};
                case CUSTOM -> new int[]{hex(customGood, 0x55FF55), hex(customWarn, 0xFFFF55),
                        hex(customOrange, 0xFFAA00), hex(customBad, 0xFF5555), hex(customNoData, 0xAAAAAA)};
                default -> new int[]{0x55FF55, 0xFFFF55, 0xFFAA00, 0xFF5555, 0xAAAAAA};
            };
        }
        return palette;
    }

    private static int hex(String s, int fallback) {
        try { return Integer.parseInt(s.replace("#", "").trim(), 16) & 0xFFFFFF; } catch (Exception e) { return fallback; }
    }
}
