package com.example.armorest.model;

public enum ArmorSlot {
    HEAD("H", 11), CHEST("C", 16), LEGS("L", 15), FEET("B", 13);

    public static final ArmorSlot[] VALUES = values();
    private final String shortName;
    private final int baseDurability;

    ArmorSlot(String shortName, int baseDurability) {
        this.shortName = shortName;
        this.baseDurability = baseDurability;
    }

    public String shortName() { return shortName; }
    /** Vanilla per-slot durability base (multiplied by the material multiplier). */
    public int baseDurability() { return baseDurability; }
}
