package com.example.armorest.model;

/** Immutable log entry of one hit (kept in a small bounded ring per opponent). */
public record CombatEvent(String uuid, String name, long timeMs, double rawModel, double observed,
                          AttackType type, WeaponCategory weapon, boolean fullCharge, int streak,
                          long sinceLastHitMs, boolean blocking, boolean reduced, String outcome) {}
