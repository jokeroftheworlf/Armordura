package com.example.armorest.estimate;

import com.example.armorest.model.ArmorMaterialType;
import com.example.armorest.model.ArmorSlot;
import com.example.armorest.model.Confidence;

import java.util.List;

/** Immutable snapshot of an estimate. Every number here is an ESTIMATE, never a real durability reading. */
public record EstimateResult(
        boolean hasData, boolean noArmor, boolean insufficient,
        double conditionPct, double worstPct, double bestPct, double wearPct,
        Category category, Confidence confidence, double confidenceScore, String dataQuality,
        SlotEstimate[] slots, List<String> confidenceNotes, List<String> unknowns, List<String> assumptions,
        int effectiveHits) {

    public enum Category {
        GOOD("LIKELY GOOD"), WORN("NOTICEABLE WEAR"), HEAVY("HEAVILY WORN"), CRITICAL("NEAR BREAKING"), NO_DATA("NO DATA");
        private final String label;
        Category(String l) { label = l; }
        public String label() { return label; }
    }

    /** material == null means the slot is empty. */
    public record SlotEstimate(ArmorSlot slot, ArmorMaterialType material, double conditionPct,
                               double worstPct, double bestPct, double maxDurability) {}
}
