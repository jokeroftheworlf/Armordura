package com.example.armorest.track;

import com.example.armorest.estimate.EstimateResult;
import com.example.armorest.estimate.Params;
import com.example.armorest.model.WeaponCategory;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Plain-text report of a profile (used by /armorest stats and /armorest info). */
public final class Stats {
    private Stats() {}

    public static List<String> summary(OpponentProfile p, Params params) {
        EstimateResult r = p.estimator.estimate(params);
        List<String> l = new ArrayList<>();
        l.add("== " + p.name + " (ESTIMATE, not a real durability reading) ==");
        if (!r.hasData()) {
            l.add("No damaging hits observed yet.");
        } else if (r.noArmor()) {
            l.add("Target wears no recognised armor.");
        } else {
            l.add(String.format(Locale.ROOT, "Armor condition ~%.0f%% (plausible %.0f-%.0f%%), wear ~%.0f%%",
                    r.conditionPct(), r.worstPct(), r.bestPct(), r.wearPct()));
            StringBuilder sb = new StringBuilder("Pieces: ");
            for (EstimateResult.SlotEstimate s : r.slots()) {
                sb.append(s.slot().shortName()).append(' ');
                if (s.material() == null) sb.append("-");
                else sb.append(s.material().name()).append(String.format(Locale.ROOT, " ~%.0f%%", s.conditionPct()));
                sb.append("  ");
            }
            l.add(sb.toString().trim());
        }
        l.add("Confidence: " + r.confidence().label() + String.format(Locale.ROOT, " (%.2f)  data quality: %s", r.confidenceScore(), r.dataQuality()));
        l.add(String.format(Locale.ROOT, "Hits %d (normal %d, crit %d, smash %d)  damaging %d  damage %.1f",
                p.hits, p.normals, p.crits, p.smashes, r.effectiveHits(), p.damageDealt));
        l.add("Combo " + p.currentCombo + " (best " + p.highestCombo + ")  engagement " + p.engagementMs() / 1000 + "s");
        StringBuilder w = new StringBuilder("Weapons: ");
        for (WeaponCategory c : WeaponCategory.VALUES) if (p.weaponCounts[c.ordinal()] > 0)
            w.append(c.name()).append('x').append(p.weaponCounts[c.ordinal()]).append(' ');
        l.add(w.toString().trim());
        return l;
    }

    public static List<String> explain(OpponentProfile p, Params params) {
        EstimateResult r = p.estimator.estimate(params);
        List<String> l = new ArrayList<>();
        l.add("== Why " + r.confidence().label() + " for " + p.name + " ==");
        if (r.confidenceNotes().isEmpty()) l.add("(no confidence penalties)");
        for (String s : r.confidenceNotes()) l.add("- " + s);
        l.add("Unknown variables:");
        for (String s : r.unknowns()) l.add("- " + s);
        l.add("Model assumptions:");
        for (String s : r.assumptions()) l.add("- " + s);
        return l;
    }
}
