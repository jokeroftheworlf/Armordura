package com.example.armorest.estimate;

/** Vanilla damage formulas used by the model. Pure functions. */
public final class DamageMath {
    private DamageMath() {}

    /** Post-armor damage (ignores Protection enchants, Resistance, absorption). */
    public static double afterArmor(double damage, double armor, double toughness) {
        if (damage <= 0) return 0;
        double f = 2.0 + toughness / 4.0;
        double g = Math.min(20.0, Math.max(armor * 0.2, armor - damage / f));
        return damage * (1.0 - g / 25.0);
    }

    /** Inverse of {@link #afterArmor}: the pre-armor damage that yields {@code post}. */
    public static double invertAfterArmor(double post, double armor, double toughness) {
        if (post <= 0) return 0;
        double lo = post, hi = Math.max(post * 6.0, 40.0);
        for (int i = 0; i < 40; i++) {
            double mid = (lo + hi) / 2.0;
            if (afterArmor(mid, armor, toughness) < post) lo = mid; else hi = mid;
        }
        return (lo + hi) / 2.0;
    }

    /** Durability points each worn armor piece loses when taking {@code rawDamage} (vanilla: max(1, floor(d/4))). */
    public static int durabilityPerPiece(double rawDamage) {
        return Math.max(1, (int) Math.floor(rawDamage / 4.0));
    }

    /** Probability that one durability point is actually applied to armor with the given Unbreaking level. */
    public static double armorUseChance(int unbreaking) {
        int l = Math.max(0, unbreaking);
        return 0.6 + 0.4 / (l + 1);
    }
}
