package com.example.armorest;

import com.example.armorest.config.ConfigScreen;
import com.example.armorest.config.ModConfig;
import com.example.armorest.hud.HudRenderer;
import com.example.armorest.track.OpponentProfile;
import com.example.armorest.track.Stats;
import com.example.armorest.track.TrackerManager;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.RequiredArgumentBuilder;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.command.CommandSource;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;
import java.util.function.BiConsumer;

public class ArmorEstClient implements ClientModInitializer {
    public static final Logger LOG = LoggerFactory.getLogger("armorest");
    public static ModConfig CONFIG;
    public static TrackerManager TRACKER;

    private static KeyBinding openKey, cycleKey, clearKey;

    @Override
    public void onInitializeClient() {
        CONFIG = ModConfig.load();
        TRACKER = new TrackerManager(CONFIG);
        CONFIG.onChange = TRACKER::refreshParams;
        TRACKER.refreshParams();

        KeyBinding.Category cat = KeyBinding.Category.create(Identifier.of("armorest", "main"));
        openKey = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.armorest.settings", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_UNKNOWN, cat));
        cycleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.armorest.cycle", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_UNKNOWN, cat));
        clearKey = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.armorest.clear", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_UNKNOWN, cat));

        AttackEntityCallback.EVENT.register((player, world, hand, entity, hit) -> {
            if (world.isClient() && entity instanceof PlayerEntity target) {
                MinecraftClient mc = MinecraftClient.getInstance();
                if (player == mc.player) TRACKER.onAttack(player, target);
            }
            return ActionResult.PASS;
        });

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            TRACKER.onTick(mc);
            while (openKey.wasPressed()) openSettings();
            while (cycleKey.wasPressed()) TRACKER.cycleTarget();
            while (clearKey.wasPressed()) { TRACKER.clearAll(); debug("cleared all tracking data"); }
        });

        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> TRACKER.onJoin());
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> TRACKER.onDisconnect());
        ClientLifecycleEvents.CLIENT_STOPPING.register(client -> TRACKER.saveIfEnabled());

        // Drawn just before chat so chat always stays on top of it.
        HudElementRegistry.attachElementBefore(VanillaHudElements.CHAT, Identifier.of("armorest", "hud"), HudRenderer::render);

        registerCommands();
    }

    // ------------------------------------------------------------------ helpers

    public static void debug(String s) {
        LOG.info(s);
        MinecraftClient mc = MinecraftClient.getInstance();
        if (CONFIG != null && CONFIG.debug && mc.player != null) mc.player.sendMessage(Text.literal("[ArmorEst] " + s), false);
    }

    private static void openSettings() {
        MinecraftClient mc = MinecraftClient.getInstance();
        mc.execute(() -> mc.setScreen(new ConfigScreen(mc.currentScreen, CONFIG)));
    }

    private static void msg(FabricClientCommandSource src, String s) { src.sendFeedback(Text.literal(s)); }

    private static void msgAll(FabricClientCommandSource src, List<String> lines) { for (String l : lines) msg(src, l); }

    private static List<String> names() {
        MinecraftClient mc = MinecraftClient.getInstance();
        List<String> n = new ArrayList<>();
        if (mc.world != null) for (PlayerEntity p : mc.world.getPlayers()) if (p != mc.player) n.add(p.getName().getString());
        for (OpponentProfile pr : TRACKER.all()) if (!n.contains(pr.name)) n.add(pr.name);
        return n;
    }

    private static RequiredArgumentBuilder<FabricClientCommandSource, String> playerArg(BiConsumer<FabricClientCommandSource, OpponentProfile> action) {
        return ClientCommandManager.argument("player", StringArgumentType.word())
                .suggests((ctx, b) -> CommandSource.suggestMatching(names(), b))
                .executes(ctx -> {
                    OpponentProfile pr = TRACKER.find(MinecraftClient.getInstance(), StringArgumentType.getString(ctx, "player"));
                    if (pr == null) { msg(ctx.getSource(), "Unknown player (must be nearby or already tracked)."); return 0; }
                    action.accept(ctx.getSource(), pr);
                    return 1;
                });
    }

    private static void registerCommands() {
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> dispatcher.register(
                ClientCommandManager.literal("armorest")
                        .executes(ctx -> { openSettings(); return 1; })
                        .then(ClientCommandManager.literal("toggle").executes(ctx -> {
                            CONFIG.enabled = !CONFIG.enabled; CONFIG.changed();
                            msg(ctx.getSource(), "Armor Estimator " + (CONFIG.enabled ? "ON" : "OFF")); return 1; }))
                        .then(ClientCommandManager.literal("hud").executes(ctx -> {
                            CONFIG.hudEnabled = !CONFIG.hudEnabled; CONFIG.changed();
                            msg(ctx.getSource(), "HUD " + (CONFIG.hudEnabled ? "ON" : "OFF")); return 1; }))
                        .then(ClientCommandManager.literal("debug").executes(ctx -> {
                            CONFIG.debug = !CONFIG.debug; CONFIG.changed();
                            msg(ctx.getSource(), "Debug " + (CONFIG.debug ? "ON" : "OFF")); return 1; }))
                        .then(ClientCommandManager.literal("clear").executes(ctx -> {
                            TRACKER.clearAll(); msg(ctx.getSource(), "Cleared all tracking data."); return 1; }))
                        .then(ClientCommandManager.literal("select").executes(ctx -> {
                            OpponentProfile pr = TRACKER.selectCrosshair(MinecraftClient.getInstance());
                            msg(ctx.getSource(), pr == null ? "Look at a player first." : "Manual target: " + pr.name);
                            return pr == null ? 0 : 1; }))
                        .then(ClientCommandManager.literal("auto").executes(ctx -> {
                            TRACKER.selectAutomatic(); msg(ctx.getSource(), "Target mode: AUTOMATIC"); return 1; }))
                        .then(ClientCommandManager.literal("target").then(playerArg((s, pr) -> {
                            TRACKER.selectManual(pr); msg(s, "Manual target: " + pr.name); })))
                        .then(ClientCommandManager.literal("remove").then(playerArg((s, pr) -> {
                            TRACKER.remove(pr); msg(s, "Removed " + pr.name); })))
                        .then(ClientCommandManager.literal("reset").then(playerArg((s, pr) -> {
                            TRACKER.reset(pr); msg(s, "Reset record of " + pr.name); })))
                        .then(ClientCommandManager.literal("stats")
                                .executes(ctx -> {
                                    OpponentProfile pr = TRACKER.current();
                                    if (pr == null) { msg(ctx.getSource(), "No current target."); return 0; }
                                    msgAll(ctx.getSource(), Stats.summary(pr, TRACKER.params())); return 1; })
                                .then(playerArg((s, pr) -> msgAll(s, Stats.summary(pr, TRACKER.params())))))
                        .then(ClientCommandManager.literal("info")
                                .executes(ctx -> {
                                    OpponentProfile pr = TRACKER.current();
                                    if (pr == null) { msg(ctx.getSource(), "No current target."); return 0; }
                                    msgAll(ctx.getSource(), Stats.explain(pr, TRACKER.params())); return 1; })
                                .then(playerArg((s, pr) -> msgAll(s, Stats.explain(pr, TRACKER.params())))))
        ));
    }
}
