# Armor Estimator (Fabric, Minecraft 1.21.11, Java 21, Yarn)

Client-side PvP utility. It **estimates** how worn an opponent's armor is from combat events you can legitimately
observe. It never reads the opponent's real durability, and every number on screen is labelled `EST.` / `~`.

## What the client can and cannot know
| Observable (used) | Not knowable (assumed + shown as uncertainty) |
|---|---|
| Your own hits: weapon, attack cooldown, fall state, attack-damage attribute | Target's Unbreaking / Mending / repairs |
| Target health+absorption drop after your hit (damage dealt) | Armor durability before tracking began |
| Target armor *item types* (material and slot, no durability) | Protection enchants (change damage taken, not wear) |
| Target shield raised, target armor swaps, target leaving/rejoining | Damage from other players (only detected as "unattributed") |
| Whether health dropped with no hit of yours to explain it | Whether a crit really happened server-side (it is *predicted* from client state) |

## Estimation model (src/main/java/.../estimate)
Vanilla rule: when armor-affecting damage `D` (pre-armor, after shield and invulnerability-frame reduction) lands, every
worn piece loses `max(1, floor(D/4))` durability. Unbreaking lets a point be skipped, so each point applies with chance
`0.6 + 0.4/(L+1)`.

For each damaging hit the engine:
1. Models `D` = attack attribute x cooldown scale (0.2+0.8t^2) x 1.5 if predicted crit (+ mace smash bonus x cooldown).
2. Applies invulnerability frames (hits within 10 ticks only deal the excess over the previous hit).
3. Compares the *observed* post-armor damage with the vanilla armor formula for the target's identified armor. If more
   damage got through than modelled (e.g. unmodelled Sharpness) the raw damage is corrected upward; a hit that did no
   damage (blocked, i-frames) causes no wear.
4. Accumulates three per-slot wear totals: **central** (assumed Unbreaking, default II), **best case** (Unbreaking III, lower D)
   and **worst case** (no Unbreaking, higher D, plus any unattributed damage). Result = condition ~% with a plausible range.

Hit count alone is never converted to a percentage: a 7-damage hit and a 4-damage hit cost the same, an 8-damage hit costs double.

## Confidence (VERY LOW / LOW / MODERATE / HIGH)
A weighted score, gated by evidence, from: number of damaging hits, share of armor with known material, share of hits whose
damage was observed, agreement between observed and modelled damage, width of the plausible range, session integrity
(armor swaps, tracking gaps, unknown-source damage) and a fixed "starting condition unknown" factor. It does **not** grow
with time. `/armorest info` lists exactly which factors lowered it.

## Architecture
```
model/      pure data: ArmorSlot, ArmorMaterialType, ArmorItems, WeaponCategory, AttackType, Confidence, records
estimate/   pure engine: DurabilityEstimator, DamageMath, Params, EstimateResult   (unit-tested, no Minecraft)
track/      TrackerManager (events + per-tick health watch), OpponentProfile, Stats
hud/        HudRenderer (cached panels, rebuilt only when inputs change)
config/     ModConfig (JSON), ConfigScreen (dependency-free settings menu)
ArmorEstClient  wiring: attack callback, tick, keybinds, commands, HUD registration
```
Performance: event-driven. Per tick only profiles that are in combat are touched; nearest-player scan runs 2x/second;
HUD strings are cached; profiles are purged after the retention time and cleared on disconnect.

## Use
* Hit a player: the HUD appears. Settings: `/armorest` or the "Open settings" key (unbound by default, set it in Controls).
* `/armorest target <player>` | `select` (crosshair) | `auto` | `remove <p>` | `reset <p>` | `clear` | `stats [p]` | `info [p]` | `toggle` | `hud` | `debug`
* Target modes: AUTOMATIC, MANUAL, NEAREST, LAST_HIT, MULTI_TARGET. Custom colors: edit `config/armorest.json` (Color scheme = CUSTOM).
* Data is kept in memory only, unless "Persist between sessions" is on (`config/armorest-data.json`).

## Debugging
`/armorest debug` prints every detected hit, resolved damage observation, crit/smash classification, target UUID, estimator
update + confidence, armor change, unattributed damage and tracking gap to chat and `logs/latest.log`.

## Build
**GitHub (zip workflow):** upload `mod.zip` to the repo root (replace the old one), keep the `build.yml` workflow, open
Actions, download the `truehp-mod` artifact (the jar inside is your mod; the artifact name is set in build.yml).
**Local:** JDK 21 + Gradle, `gradle build`, jar in `build/libs/`.
Unit tests (`src/test`) run on every build and are logged; a failing test does not block the jar.

## Honest limitations
* Unbreaking/Mending/repairs and starting durability are unknowable: expect ranges, not exact values.
* Crits and mace smashes are predicted from your own client state, not confirmed by the server.
* Very high ping can delay the health update past the observation window; hits are then logged as "no damage".
* Copper and modded armor are treated as UNKNOWN material (no invented stats).
* Some servers treat any combat-info overlay as unfair; check the rules of the server you play on.
