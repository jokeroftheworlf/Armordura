package com.example.armorest.model;

public enum Confidence {
    VERY_LOW("VERY LOW"), LOW("LOW"), MODERATE("MODERATE"), HIGH("HIGH");

    private final String label;
    Confidence(String label) { this.label = label; }
    public String label() { return label; }

    public static Confidence fromScore(double s) {
        if (s < 0.30) return VERY_LOW;
        if (s < 0.50) return LOW;
        if (s < 0.70) return MODERATE;
        return HIGH;
    }
}
