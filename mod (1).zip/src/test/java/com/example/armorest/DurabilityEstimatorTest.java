package com.example.armorest;

import com.example.armorest.estimate.*;
import com.example.armorest.model.*;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/** Controlled simulated combat. Pure Java: no Minecraft needed. */
class DurabilityEstimatorTest {
    private final Params p = new Params();
    private static final double ARMOR = 20, TOUGH = 8; // full diamond

    private static DurabilityEstimator estimatorWith(ArmorMaterialType m) {
        DurabilityEstimator e = new DurabilityEstimator();
        e.setInitialArmor(new ArmorMaterialType[]{m, m, m, m});
        return e;
    }

    private static HitObservation hit(double raw, double obs, long tick, AttackType t) {
        return new HitObservation(raw, obs, false, tick, t, WeaponCategory.SWORD, true);
    }

    private static void assertValid(EstimateResult r) {
        assertTrue(r.conditionPct() >= 0 && r.conditionPct() <= 100, "condition in bounds");
        assertTrue(r.worstPct() >= 0 && r.bestPct() <= 100, "range in bounds");
        assertTrue(r.worstPct() <= r.conditionPct() + 1e-9, "worst <= central");
        assertTrue(r.conditionPct() <= r.bestPct() + 1e-9, "central <= best");
        assertTrue(r.confidenceScore() >= 0 && r.confidenceScore() <= 1, "confidence in bounds");
        assertFalse(Double.isNaN(r.conditionPct()));
    }

    @Test void oneNormalHit() {
        DurabilityEstimator e = estimatorWith(ArmorMaterialType.DIAMOND);
        e.recordHit(hit(8, DamageMath.afterArmor(8, ARMOR, TOUGH), 0, AttackType.NORMAL), p);
        EstimateResult r = e.estimate(p);
        assertValid(r);
        assertTrue(r.conditionPct() > 98);
        assertEquals(Confidence.VERY_LOW, r.confidence());
    }

    @Test void tenNormalHits() {
        DurabilityEstimator e = estimatorWith(ArmorMaterialType.DIAMOND);
        for (int i = 0; i < 10; i++) e.recordHit(hit(8, DamageMath.afterArmor(8, ARMOR, TOUGH), i * 20L, AttackType.NORMAL), p);
        EstimateResult r = e.estimate(p);
        assertValid(r);
        assertTrue(r.conditionPct() < 99 && r.conditionPct() > 90);
        assertEquals(10, r.effectiveHits());
    }

    @Test void criticalsWearMoreThanNormalsForSameCount() {
        DurabilityEstimator n = estimatorWith(ArmorMaterialType.DIAMOND);
        DurabilityEstimator c = estimatorWith(ArmorMaterialType.DIAMOND);
        for (int i = 0; i < 10; i++) {
            n.recordHit(hit(7, DamageMath.afterArmor(7, ARMOR, TOUGH), i * 20L, AttackType.NORMAL), p);   // floor(7/4)=1
            c.recordHit(hit(10.5, DamageMath.afterArmor(10.5, ARMOR, TOUGH), i * 20L, AttackType.CRITICAL), p); // floor(10.5/4)=2
        }
        assertValid(c.estimate(p));
        assertTrue(c.estimate(p).conditionPct() < n.estimate(p).conditionPct());
    }

    @Test void damageIsNotLinearInHits() {
        // 7 damage and 4 damage both cost exactly 1 point per piece: the model is not "hits * constant"
        assertEquals(1, DamageMath.durabilityPerPiece(4.0));
        assertEquals(1, DamageMath.durabilityPerPiece(7.9));
        assertEquals(2, DamageMath.durabilityPerPiece(8.0));
        assertEquals(1, DamageMath.durabilityPerPiece(0.5)); // minimum 1
    }

    @Test void mixedAttacksAndDifferentDamage() {
        DurabilityEstimator e = estimatorWith(ArmorMaterialType.IRON);
        double[] raws = {4, 6, 9, 12, 5, 7.5, 10};
        AttackType[] ty = {AttackType.NORMAL, AttackType.NORMAL, AttackType.NORMAL, AttackType.CRITICAL,
                AttackType.NORMAL, AttackType.NORMAL, AttackType.CRITICAL};
        for (int i = 0; i < raws.length; i++)
            e.recordHit(hit(raws[i], DamageMath.afterArmor(raws[i], 15, 0), i * 15L, ty[i]), p);
        assertValid(e.estimate(p));
    }

    @Test void unknownArmorLowersConfidence() {
        DurabilityEstimator known = estimatorWith(ArmorMaterialType.DIAMOND);
        DurabilityEstimator unknown = estimatorWith(ArmorMaterialType.UNKNOWN);
        for (int i = 0; i < 15; i++) {
            known.recordHit(hit(8, DamageMath.afterArmor(8, ARMOR, TOUGH), i * 20L, AttackType.NORMAL), p);
            unknown.recordHit(hit(8, 2.2, i * 20L, AttackType.NORMAL), p);
        }
        assertValid(unknown.estimate(p));
        assertTrue(unknown.estimate(p).confidenceScore() < known.estimate(p).confidenceScore());
    }

    @Test void unobservedDamageLowersConfidence() {
        DurabilityEstimator a = estimatorWith(ArmorMaterialType.DIAMOND);
        DurabilityEstimator b = estimatorWith(ArmorMaterialType.DIAMOND);
        for (int i = 0; i < 15; i++) {
            a.recordHit(hit(8, DamageMath.afterArmor(8, ARMOR, TOUGH), i * 20L, AttackType.NORMAL), p);
            b.recordHit(hit(8, Double.NaN, i * 20L, AttackType.NORMAL), p);
        }
        assertTrue(b.estimate(p).confidenceScore() < a.estimate(p).confidenceScore());
        assertValid(b.estimate(p));
    }

    @Test void armorReplacementResetsWearAndLowersConfidence() {
        DurabilityEstimator e = estimatorWith(ArmorMaterialType.DIAMOND);
        for (int i = 0; i < 20; i++) e.recordHit(hit(8, DamageMath.afterArmor(8, ARMOR, TOUGH), i * 20L, AttackType.NORMAL), p);
        EstimateResult before = e.estimate(p);
        e.onArmorChanged(ArmorSlot.CHEST, ArmorMaterialType.NETHERITE);
        EstimateResult after = e.estimate(p);
        assertValid(after);
        assertTrue(after.conditionPct() > before.conditionPct());
        assertTrue(after.confidenceScore() < before.confidenceScore());
    }

    @Test void combatInterruptionMarksGap() {
        DurabilityEstimator e = estimatorWith(ArmorMaterialType.DIAMOND);
        for (int i = 0; i < 20; i++) e.recordHit(hit(8, DamageMath.afterArmor(8, ARMOR, TOUGH), i * 20L, AttackType.NORMAL), p);
        double before = e.estimate(p).confidenceScore();
        e.markGap();
        assertTrue(e.estimate(p).confidenceScore() < before);
    }

    @Test void incompleteDataStillValid() {
        DurabilityEstimator e = new DurabilityEstimator(); // no armor info at all
        assertValid(e.estimate(p));
        assertTrue(e.estimate(p).noArmor());
        e.recordHit(hit(8, Double.NaN, 0, AttackType.NORMAL), p);
        assertValid(e.estimate(p));
    }

    @Test void multipleAttackersWidenWorstCaseOnly() {
        DurabilityEstimator e = estimatorWith(ArmorMaterialType.DIAMOND);
        for (int i = 0; i < 10; i++) e.recordHit(hit(8, DamageMath.afterArmor(8, ARMOR, TOUGH), i * 20L, AttackType.NORMAL), p);
        EstimateResult before = e.estimate(p);
        e.recordUnattributedDamage(4);
        EstimateResult after = e.estimate(p);
        assertValid(after);
        assertEquals(before.conditionPct(), after.conditionPct(), 1e-9);
        assertTrue(after.worstPct() < before.worstPct());
        assertTrue(after.confidenceScore() < before.confidenceScore());
    }

    @Test void invulnerabilityFramesAbsorbRepeatHit() {
        DurabilityEstimator e = estimatorWith(ArmorMaterialType.DIAMOND);
        double post = DamageMath.afterArmor(8, ARMOR, TOUGH);
        e.recordHit(hit(8, post, 0, AttackType.NORMAL), p);
        DurabilityEstimator.HitResult r = e.recordHit(hit(8, 0.0, 3, AttackType.NORMAL), p);
        assertEquals(DurabilityEstimator.Outcome.NO_DAMAGE, r.outcome());
        assertEquals(1, e.effectiveHits());
    }

    @Test void blockedHitCausesNoWear() {
        DurabilityEstimator e = estimatorWith(ArmorMaterialType.DIAMOND);
        e.recordHit(new HitObservation(8, 0.0, true, 0, AttackType.NORMAL, WeaponCategory.SWORD, true), p);
        assertEquals(0, e.effectiveHits());
        assertEquals(100.0, e.estimate(p).conditionPct(), 1e-9);
    }

    @Test void neverImpossibleValuesUnderHeavyAbuse() {
        for (ArmorMaterialType m : ArmorMaterialType.values()) {
            DurabilityEstimator e = estimatorWith(m);
            for (int i = 0; i < 3000; i++) e.recordHit(hit(40, 15, i * 20L, AttackType.SMASH), p);
            e.recordUnattributedDamage(500);
            assertValid(e.estimate(p));
        }
    }

    @Test void armorIdParsing() {
        ArmorItems.Parsed d = ArmorItems.parse("minecraft:diamond_chestplate");
        assertEquals(ArmorSlot.CHEST, d.slot());
        assertEquals(ArmorMaterialType.DIAMOND, d.material());
        assertEquals(528, d.material().maxDurability(ArmorSlot.CHEST));
        assertEquals(ArmorMaterialType.GOLD, ArmorItems.parse("minecraft:golden_boots").material());
        assertEquals(275, ArmorMaterialType.TURTLE.maxDurability(ArmorSlot.HEAD));
        assertEquals(ArmorMaterialType.UNKNOWN, ArmorItems.parse("othermod:ruby_helmet").material());
        assertNull(ArmorItems.parse("minecraft:elytra"));
        assertNull(ArmorItems.parse("minecraft:diamond_sword"));
    }

    @Test void damageMathRoundTrips() {
        for (double d : new double[]{1, 5, 8, 15, 40}) {
            double post = DamageMath.afterArmor(d, ARMOR, TOUGH);
            assertEquals(d, DamageMath.invertAfterArmor(post, ARMOR, TOUGH), 1e-3);
        }
    }

    @Test void weaponClassification() {
        assertEquals(WeaponCategory.SWORD, WeaponCategory.classify("minecraft:netherite_sword", 8));
        assertEquals(WeaponCategory.AXE, WeaponCategory.classify("minecraft:diamond_axe", 9));
        assertEquals(WeaponCategory.OTHER_MELEE, WeaponCategory.classify("minecraft:diamond_pickaxe", 5));
        assertEquals(WeaponCategory.MACE, WeaponCategory.classify("minecraft:mace", 6));
        assertEquals(WeaponCategory.UNKNOWN, WeaponCategory.classify("minecraft:air", 1));
    }
}
