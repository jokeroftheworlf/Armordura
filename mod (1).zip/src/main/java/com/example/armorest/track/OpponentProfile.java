package com.example.armorest.track;

import com.example.armorest.estimate.DurabilityEstimator;
import com.example.armorest.model.AttackType;
import com.example.armorest.model.CombatEvent;
import com.example.armorest.model.WeaponCategory;

import java.util.ArrayDeque;
import java.util.UUID;

/** Everything we know about ONE opponent. Fields that are not transient may be persisted (opt-in). */
public final class OpponentProfile {
    public enum Status { ACTIVE, IDLE, STALE }

    /** A landed hit whose damage we have not been able to observe yet (health sync arrives a few ticks later). */
    public static final class Pending {
        public final long tick, timeMs;
        public double hpAtHit;
        public final double rawModel;
        public final AttackType type;
        public final WeaponCategory weapon;
        public final boolean full, blocking;
        public final int streak;
        public final long sinceLastMs;

        public Pending(long tick, long timeMs, double hpAtHit, double rawModel, AttackType type, WeaponCategory weapon,
                       boolean full, boolean blocking, int streak, long sinceLastMs) {
            this.tick = tick; this.timeMs = timeMs; this.hpAtHit = hpAtHit; this.rawModel = rawModel;
            this.type = type; this.weapon = weapon; this.full = full; this.blocking = blocking;
            this.streak = streak; this.sinceLastMs = sinceLastMs;
        }
    }

    // ---- persisted
    public String uuid;
    public String name = "?";
    public int hits, crits, normals, smashes;
    public double damageDealt;
    public int highestCombo;
    public long lastCombatMs, lastTouchMs, engagedTotalMs;
    public WeaponCategory lastWeapon = WeaponCategory.UNKNOWN;
    public int[] weaponCounts = new int[WeaponCategory.VALUES.length];
    public String[] armorIds = new String[4];
    public boolean armorInit;
    public DurabilityEstimator estimator = new DurabilityEstimator();

    // ---- runtime only
    public transient int currentCombo;
    public transient long lastHitMs, comboStartMs, engagementStartMs, missingSinceMs;
    public transient double lastHp = Double.NaN;
    public transient boolean staleMarked;
    public transient ArrayDeque<Pending> pending = new ArrayDeque<>();
    public transient ArrayDeque<CombatEvent> events = new ArrayDeque<>();
    public transient Object hudCache;
    public transient long hudKey;
    private transient UUID id;

    public OpponentProfile() {}

    public UUID id() {
        if (id == null) id = UUID.fromString(uuid);
        return id;
    }

    public void addEvent(CombatEvent e) {
        if (events == null) events = new ArrayDeque<>();
        if (events.size() >= 64) events.pollFirst();
        events.addLast(e);
    }

    public long engagementMs() {
        return engagementStartMs > 0 && lastCombatMs >= engagementStartMs ? lastCombatMs - engagementStartMs : 0;
    }

    public Status status(long now, int combatTimeoutSec, int staleMinutes) {
        long age = now - lastCombatMs;
        if (age <= combatTimeoutSec * 1000L) return Status.ACTIVE;
        if (age <= staleMinutes * 60_000L) return Status.IDLE;
        return Status.STALE;
    }
}
