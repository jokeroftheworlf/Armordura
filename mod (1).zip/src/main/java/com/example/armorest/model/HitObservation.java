package com.example.armorest.model;

/**
 * One landed melee hit as seen by the client.
 * @param rawModel     modelled pre-armor damage (attribute * cooldown scaling * crit/smash), unknown extras excluded
 * @param observedPost observed post-armor damage (health+absorption drop), or NaN if it could not be observed
 * @param blocking     target was holding a shield up
 * @param tick         client tick of the hit (used for invulnerability-frame modelling)
 */
public record HitObservation(double rawModel, double observedPost, boolean blocking, long tick,
                             AttackType type, WeaponCategory weapon, boolean fullCharge) {}
