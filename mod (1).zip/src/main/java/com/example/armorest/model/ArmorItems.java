package com.example.armorest.model;

/** Maps an item registry id (e.g. "minecraft:diamond_helmet") to slot + material. Only item identity is used. */
public final class ArmorItems {
    private ArmorItems() {}

    public record Parsed(ArmorSlot slot, ArmorMaterialType material) {}

    /** @return null if the id is not an armor piece. Non-vanilla / unrecognised materials become UNKNOWN. */
    public static Parsed parse(String id) {
        if (id == null) return null;
        String ns = "minecraft";
        String path = id;
        int colon = id.indexOf(':');
        if (colon >= 0) { ns = id.substring(0, colon); path = id.substring(colon + 1); }

        ArmorSlot slot;
        String prefix;
        if (path.endsWith("_helmet")) { slot = ArmorSlot.HEAD; prefix = path.substring(0, path.length() - 7); }
        else if (path.endsWith("_chestplate")) { slot = ArmorSlot.CHEST; prefix = path.substring(0, path.length() - 11); }
        else if (path.endsWith("_leggings")) { slot = ArmorSlot.LEGS; prefix = path.substring(0, path.length() - 9); }
        else if (path.endsWith("_boots")) { slot = ArmorSlot.FEET; prefix = path.substring(0, path.length() - 6); }
        else return null;

        ArmorMaterialType m = ArmorMaterialType.UNKNOWN;
        if (ns.equals("minecraft")) {
            m = switch (prefix) {
                case "leather" -> ArmorMaterialType.LEATHER;
                case "golden" -> ArmorMaterialType.GOLD;
                case "chainmail" -> ArmorMaterialType.CHAINMAIL;
                case "iron" -> ArmorMaterialType.IRON;
                case "diamond" -> ArmorMaterialType.DIAMOND;
                case "netherite" -> ArmorMaterialType.NETHERITE;
                case "turtle" -> slot == ArmorSlot.HEAD ? ArmorMaterialType.TURTLE : ArmorMaterialType.UNKNOWN;
                default -> ArmorMaterialType.UNKNOWN; // e.g. copper or modded: do not fabricate stats
            };
        }
        return new Parsed(slot, m);
    }
}
