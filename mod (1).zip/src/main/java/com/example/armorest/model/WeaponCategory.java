package com.example.armorest.model;

public enum WeaponCategory {
    SWORD, AXE, MACE, OTHER_MELEE, UNKNOWN;

    public static final WeaponCategory[] VALUES = values();

    /** @param id item registry id of the held item, "minecraft:air" for empty hand */
    public static WeaponCategory classify(String id, double attackDamage) {
        if (id == null || id.endsWith(":air")) return UNKNOWN;
        String path = id.substring(id.indexOf(':') + 1);
        if (path.endsWith("_sword")) return SWORD;
        if (path.endsWith("_axe") && !path.endsWith("pickaxe")) return AXE;
        if (path.equals("mace")) return MACE;
        return attackDamage > 1.5 ? OTHER_MELEE : UNKNOWN;
    }
}
